<?php get_header(); ?>
<div class="container">
    		<div class="page_content">
			<?php woocommerce_content(); ?>
		   </div><!-- site-aligner -->
    </div><!-- content -->
     
<?php get_footer(); ?>